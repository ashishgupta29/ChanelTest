﻿using RockPaperScissors.Interface;
using System;

namespace RockPaperScissors.Service
{
    public class ConsoleWrapperService: IConsoleWrapperService
    {
        public string ReadLine()
        {
            return Console.ReadLine();
        }

        public virtual void WriteLine(string value = null)
        {
            if(value == null)
            {
                Console.WriteLine();
                return;
            }

            Console.WriteLine(value);
        }
    }
}
