﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RockPaperScissors.Service.Interface
{
    public interface IGame
    {
        void Play(int numberOfGamesToWin);
    }
}
