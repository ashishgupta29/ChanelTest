﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RockPaperScissors.Service.Interface
{
    public interface ISelectionValidator
    {
        bool IsValid(string choice);
    }
}
