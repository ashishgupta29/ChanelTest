﻿using PaperScissorsRockApp.Domain.Enum;
using RockPaperScissors.Domain;

namespace RockPaperScissors.Service
{
    public interface ISelectionService
    {
        Choice GetRandomSelection();
        ScoreBoard CompareSelection(Choice human, Choice computer);
    }
}
