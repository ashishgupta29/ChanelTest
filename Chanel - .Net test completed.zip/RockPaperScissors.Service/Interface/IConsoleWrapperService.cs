﻿namespace RockPaperScissors.Interface
{
    public interface IConsoleWrapperService
    {
        public void WriteLine(string value = null);
        public string ReadLine();
    }
}
