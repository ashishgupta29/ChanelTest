﻿using PaperScissorsRockApp.Domain.Enum;
using PaperScissorsRockApp.Service;
using RockPaperScissors.Domain;
using System;
using System.Linq;

namespace RockPaperScissors.Service
{
    /// <summary>
    /// Selection Service
    /// </summary>
    public class SelectionService : ISelectionService
    {
        /// <summary>
        /// Get random selection
        /// </summary>
        /// <returns></returns>
        public Choice GetRandomSelection()
        {
            var rdm = new Random();
            var list = ChoiceHelper.ChoiceAsList();
            return (Choice)rdm.Next(list.Min(), list.Max());
        }


        /// <summary>
        /// Compares human and computer selections against rules
        /// </summary>
        public ScoreBoard CompareSelection(Choice human, Choice computer)
        {
            if (GetWinningSelection(human).Equals(computer))
            {
                // Computer wins
                return new ScoreBoard(0, 1);
            }
            else if (GetWinningSelection(computer).Equals(human))
            {
                // Human wins
                return new ScoreBoard(1, 0);
            }
            else
            {
                // Draw
                return new ScoreBoard(0, 0);
            }
        }

        /// <summary>
        /// Get winning selection
        /// </summary>
        /// <param name="choice"></param>
        /// <returns></returns>
        private Choice GetWinningSelection(Choice choice)
        {
            switch (choice)
            {
                case Choice.Rock:
                    return Choice.Paper;
                case Choice.Paper:
                    return Choice.Scissors;
                default:
                    return Choice.Rock;
            }
        }
    }
}
