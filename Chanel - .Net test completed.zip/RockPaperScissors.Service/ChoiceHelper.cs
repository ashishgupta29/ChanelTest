﻿using PaperScissorsRockApp.Domain.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PaperScissorsRockApp.Service
{
    /// <summary>
    /// Helper static class
    /// </summary>
    public static class ChoiceHelper
    {
        /// <summary>
        /// Convert Choice enum to Dictionary
        /// </summary>
        /// <returns></returns>
        public static Dictionary<int, string> ChoiceAsDictionary()
        {
            return Enum.GetValues(typeof(Choice)).Cast<Choice>().ToDictionary(c => (int)c, c => c.ToString());
        }

        /// <summary>
        /// Convert Choice enum to int List
        /// </summary>
        /// <returns></returns>
        public static List<int> ChoiceAsList()
        {
            return Enum.GetValues(typeof(Choice)).Cast<int>().ToList();
        }
    }
}
