﻿using RockPaperScissors.Service.Interface;

namespace PaperScissorsRockApp.Service
{
    /// <summary>
    /// Validation against users selection
    /// </summary>
    public class SelectionValidator : ISelectionValidator
    {
        public bool IsValid(string choice)
        {
            int result;
            if (!int.TryParse(choice, out result))
            {
                return false;
            }

            return ChoiceHelper.ChoiceAsList().Contains(result);
        }
    }
}
