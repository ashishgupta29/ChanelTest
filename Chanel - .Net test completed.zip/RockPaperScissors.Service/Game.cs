﻿using RockPaperScissors.Service;
using RockPaperScissors.Service.Interface;
using PaperScissorsRockApp.Domain.Enum;
using PaperScissorsRockApp.Service;
using System;
using RockPaperScissors.Interface;

namespace RockPaperScissors.Domain
{
    public class Game : IGame
    {
        private Player humanPlayer;
        private Player computerPlayer;
        private const string ExitCharacter = "x";

        private readonly ISelectionValidator selectionValidator;
        private readonly ISelectionService selectionService;
        private readonly IConsoleWrapperService consoleService;

        public Game(ISelectionValidator selectionValidator, ISelectionService selectionService, IConsoleWrapperService consoleService)
        {
            this.selectionValidator = selectionValidator;
            this.selectionService = selectionService;
            this.consoleService = consoleService;
        }

        public void Play(int numberOfGamesToWin)
        {
            this.humanPlayer = new Player("User");
            this.computerPlayer = new Player("CPU");

            var selection = string.Empty;

            // Flag to determine if game has started
            var gameStarted = false;

            while (selection != ExitCharacter)
            {
                if (!gameStarted)
                {
                    consoleService.WriteLine($"Select the number next the option you want:");
                    foreach (var choice in ChoiceHelper.ChoiceAsDictionary())
                    {
                        consoleService.WriteLine($"{choice.Key} {choice.Value}");
                    }
                    consoleService.WriteLine($"Press x to exit console.");
                    gameStarted = true;
                }
                else
                {
                    consoleService.WriteLine($"Enter your next selection.");
                }

                selection = consoleService.ReadLine();

                if (selection == ExitCharacter)
                {
                    continue;
                }

                if (!selectionValidator.IsValid(selection))
                {
                    consoleService.WriteLine($"You have entered an invalid selection, please try again.");
                    continue;
                }

                humanPlayer.Selection = (Choice)int.Parse(selection);
                computerPlayer.Selection = selectionService.GetRandomSelection();
                consoleService.WriteLine($"Your selection '{humanPlayer.Selection}' VS the Computer's selection '{computerPlayer.Selection}'");

                var scoreBoard = selectionService.CompareSelection(humanPlayer.Selection, computerPlayer.Selection);

                if (scoreBoard.Player1 == scoreBoard.Player2){
                    consoleService.WriteLine("That was a draw.");
                }
                else
                {
                    consoleService.WriteLine(scoreBoard.Player1 > scoreBoard.Player2 ? "You won that round." : "The Computer won that round.");
                }

                // Update aggregate players scores
                humanPlayer.UpdateAggregateScore(scoreBoard.Player1);
                computerPlayer.UpdateAggregateScore(scoreBoard.Player2);

                if (humanPlayer.Score == numberOfGamesToWin || computerPlayer.Score == numberOfGamesToWin)
                {
                    var winner = humanPlayer.Score > computerPlayer.Score ? "You are the overall winner!" : "The Computer is the overall winner!";
                    consoleService.WriteLine(winner);

                    // Reset
                    humanPlayer.ResetScore();
                    computerPlayer.ResetScore();
                    scoreBoard.Reset();
                    gameStarted = false;

                    consoleService.WriteLine();
                    consoleService.WriteLine("Play again.");                    
                }
            }
        }
    }
}
