﻿using RockPaperScissors.Domain;
using RockPaperScissors.Service;
using PaperScissorsRockApp.Domain.Enum;
using PaperScissorsRockApp.Service;
using System;
using System.Linq;

namespace PaperScissorsRockApp
{
    class Program
    {
        static void Main(string[] args)
        {
            // These would normally be injected via IOC
            var validator = new SelectionValidator();
            var choiceService = new SelectionService();
            var consoleWrapperService = new ConsoleWrapperService();

            var game = new Game(validator, choiceService, consoleWrapperService);
            const int numberOfGamesToWin = 2;
            game.Play(numberOfGamesToWin);

        }
    }
}
