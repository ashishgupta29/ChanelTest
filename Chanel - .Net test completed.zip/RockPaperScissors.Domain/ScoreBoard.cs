﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RockPaperScissors.Domain
{
    public class ScoreBoard
    {
        public ScoreBoard(int player1, int player2)
        {
            Player1 = player1;
            Player2 = player2;
        }

        public int Player1 { get; private set; }
        public int Player2 { get; private set; }

        public void Reset()
        {
            Player1 = 0;
            Player2 = 0;
        }
    }
}
