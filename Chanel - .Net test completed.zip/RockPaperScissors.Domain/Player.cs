﻿using PaperScissorsRockApp.Domain.Enum;
using System;
using System.Collections.Generic;
using System.Text;

namespace RockPaperScissors.Domain
{
    public class Player
    {
        string name;
        public Player(string name)
        {
            this.name = name;
        }

        /// <summary>
        /// Player's name
        /// </summary>
        public string Name { get; set; }        
        
        /// <summary>
        /// Players selection
        /// </summary>
        public Choice Selection { get; set; }
        
        /// <summary>
        /// Current score
        /// </summary>
        public int Score { get; set; }
        
        /// <summary>
        /// Update score method
        /// </summary>
        /// <param name="value"></param>
        public void UpdateAggregateScore(int value)
        {
            Score = Score + value;
        }

        /// <summary>
        /// Reset score
        /// </summary>
        public void ResetScore()
        {
            Score = 0;
        }
    }
}
