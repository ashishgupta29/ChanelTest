﻿namespace PaperScissorsRockApp.Domain.Enum
{
    public enum Choice
    {
        Paper = 1,
        Scissors,
        Rock
    }
}
